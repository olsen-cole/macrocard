Project Name: MacroCard
Project Version: #1a324482
Project Url: https://www.flux.ai/coleo/macrocard

Project Description:
Business card shaped wireless macropad with a rotary encoder, three buttons, and Bluetooth support.


